#include "../include/head.h"

void help() {
	printf("%s",LANG[26]);
	menu2(LANG[27]);
	input();
	return;
}


